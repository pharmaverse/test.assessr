library(testthat)
library(test.package.0014)

test_check("test.package.0014")
