test_that('tests work', {
  testthat::expect_equal(myfunction_plus_3(1), 4)

  testthat::expect_equal(myfunction_plus_3(2), 5)

  testthat::expect_equal(myfunction_plus_3(3), 6)
})

test_that('tests work', {
  testthat::expect_equal(myfunction_plus_3(2), 5)

  testthat::expect_equal(myfunction_plus_3(4), 7)
})
