test_that('two working tests', {
  testthat::expect_equal(myfunction_plus_1(1), 2)

  testthat::expect_equal(myfunction_plus_1(2), 3)
  })

test_that('three working tests', {
  testthat::expect_equal(myfunction_plus_1(3), 4)

  testthat::expect_equal(myfunction_plus_1(4), 5)

  testthat::expect_equal(myfunction_plus_1(5), 6)
})
