test_that('test 1 works test 2 fails', {
  testthat::expect_equal(myfunction_plus_2(1), 3)

  testthat::expect_equal(myfunction_plus_2(1), 2)
})

test_that('test 1 fails, tests 2 & 4  work, test 3 fails', {
  testthat::expect_equal(myfunction_plus_2(1), 5)

  testthat::expect_equal(myfunction_plus_2(2), 4)

  testthat::expect_equal(myfunction_plus_2(6), 10)

  testthat::expect_equal(myfunction_plus_2(6), 8)

})
