#' Adds 4 to x
#' @param x a number
#' @export
myfunction_plus_4 <- function(x) {
  checkmate::assert_numeric(x)
  x + 4
}
