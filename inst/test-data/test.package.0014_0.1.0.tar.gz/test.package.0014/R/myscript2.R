#' Adds 2 to x
#' @param x a number
#' @export
myfunction_plus_2 <- function(x) {
  checkmate::assert_numeric(x)
  x + 2
}
