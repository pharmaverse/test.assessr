#' Adds 3 to x
#' @param x a number
#' @export
myfunction_plus_3 <- function(x) {
  checkmate::assert_numeric(x)
  x + 3
}
