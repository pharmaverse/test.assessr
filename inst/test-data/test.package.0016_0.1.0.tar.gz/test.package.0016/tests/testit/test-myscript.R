assert("myfunction adds 1 to x", {
  (myfunction(1) == expected_plus_one(1))
  (myfunction(c(1, 2)) == expected_plus_one(c(1, 2)))
})
